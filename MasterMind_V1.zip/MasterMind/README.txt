Bienvenue dans le Mastermind

Réalisée par Ruben Guenoun, Paul Le Dily, Sophie Mesbahy

Pour jouer :
	1. Ouvrez un terminal et placez-vous dans le dossier des fichiers de jeu
	2. Executez la commande 'ocaml'
	3. Executez ensuite ' #use "jeu.ml";; '
	4. Enfin executez ' Jeu.mastermind "votre nom" nombre d'essais nombre de partie true/false ;;'
		Exemple 1 : 'Jeu.mastermind "Ruben" 10 3 true ;; ' vous fera jouer 3 parties avec 10 essais pour deviner le code et laissera l'Ordinateur verifier lui même ses propostion 
		
		Exemple 2 :  'Jeu.mastermind "Ruben" 10 3 false ;; ' vous fera jouer 3 parties avec 10 essais pour deviner le code et quand l'ordi jouera il vous demandera de lui donner le score de chacune de ses propositions


PS: les commandes a executer sont celles entre les ' ' :)

Bon jeu  
		

